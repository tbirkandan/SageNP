from .SageNP import NewmanPenrose
from SageNP import NewmanPenrose
